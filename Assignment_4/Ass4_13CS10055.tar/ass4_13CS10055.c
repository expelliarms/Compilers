#include "y.tab.h"
int main(){
  int x = yyparse();
  return 0;
}