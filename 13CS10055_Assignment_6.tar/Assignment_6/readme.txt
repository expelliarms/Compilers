/* --- Read me --- */
1. first run make command
2. To compile test.c, run ./compile test.c
3. Now run the file using the command ./test.out
/* --- Read me --- */